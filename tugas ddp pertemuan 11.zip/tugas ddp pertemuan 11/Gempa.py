# SOAL NO.1
class Gempa:

    def __init__(self, lokasi, skala):
        self.lokasi = lokasi
        self.skala = skala

    def dampak(self):
        if self.skala < 2:
            print(f"Gempa di {self.lokasi}: Dampak tidak terasa.")
        elif 2 <= self.skala < 4:
            print(f"Gempa di {self.lokasi}: Bangunan retak-retak.")
        elif 4 <= self.skala < 6:
            print(f"Gempa di {self.lokasi}: Bangunan roboh.")
        elif self.skala >= 6:
            print(f"Gempa di {self.lokasi}: Bangunan roboh dan berpotensi tsunami.")

if __name__ == "__main__":
    gempa1 = Gempa("Bandung", 3.5)
    gempa1.dampak()

    gempa2 = Gempa("Bali", 6.2)
    gempa2.dampak()


